# LP-000017. Create root and local agent instructions

## 1. File Name

`LP-000017-create-root-and-local-agent-instructions.md`

## 2. Status

`DRAFT`

## 3. Category

`DOCUMENTATION`

## 4. Assigned Role

`Documentation Agent`

## 5. Owning Package

`MIP-000-platform-foundation.md`

## 6. Business Objective

Create a reliable implementation foundation for all later Loyalty Platform modules without introducing premature business behavior.

## 7. Exact Scope

- `AGENTS.md`
- `apps/**/AGENTS.md`
- `services/**/AGENTS.md`
- `docs/agents/**`

## 8. Out of Scope

- `business decisions`

## 9. Required Documents

- `MIP-000-platform-foundation.md`
- `51-engineering-implementation-guide.md`
- `52-repository-structure.md`
- `54-agent-development-plan.md`
- `55-module-definition-of-done.md`
- `57-agent-prompts.md`
- `58-project-knowledge-map.md`
- `59-coding-standards.md`
- `60-release-strategy.md`
- relevant accepted ADRs

## 10. Knowledge Package

Platform Foundation Knowledge Package from `MIP-000-platform-foundation.md`.

## 11. Dependencies

Dependencies must be identified before this task moves to `READY`.

## 12. Acceptance Criteria

- Root instructions reference authoritative documents.
- Directory rules cannot weaken Blueprint.
- Allowed and forbidden behavior is explicit.
- Codex task output requirements are included.

## 13. Mandatory Tests

- documentation consistency review

## 14. Required Reviewers

- Solution Architect where architecture is affected
- QA
- Security where security or credentials are affected
- DevOps where CI, environments or infrastructure are affected
- Documentation reviewer where documentation changes

## 15. Expected Deliverables

- implementation or review summary;
- changed or reviewed files;
- tests added;
- tests executed;
- test results;
- risks;
- known limitations;
- rollback or recovery instructions;
- documentation updates;
- Definition of Done evidence;
- readiness recommendation.

## 16. Rollback Expectation

The change must be reversible through configuration rollback, code rollback, migration recovery or forward fix as appropriate. Immutable migration history must not be rewritten.

## 17. Completion Rule

The task may be marked complete only when all acceptance criteria and mandatory tests pass and required review evidence exists.
